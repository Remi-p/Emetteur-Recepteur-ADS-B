function [ Reg_out ] = Tafroute_Hourquebie( Reg_in, yl, fe, Ds, lon_ref, lat_ref )

yl = abs(yl);
%% Initialisation des variables
Te = 1/fe;
Ts = 1/Ds;
Fse = Ts/Te;
Tp=8*10^(-6);
Ntp = Tp/Te;
registre = struct('adresse',[],'format',[],'type',[],'nom',[],'altitude',[],'timeFlag',[],'cprFlag',[],'latitude',[],'longitude',[],'trajectoire',[]);
% Filtre adapt�
p_conj=cat(2,(1/2)*ones(1,Fse/2),(-1/2)*ones(1,Fse/2));

%% Pr�ambule
sp=[1 0 1 0 0 0 0 1 0 1 0 0 0 0 0 0];
% Sur�chantillonnage du pr�ambule
sptilde=kron(sp,ones(1,Fse/2));%upsample(sp,Fse/2);
% Energie du pr�ambule
E_sp=sqrt(sum(abs(sptilde).^2));

%% On applique la corr�lation sur l'ensemble du buffer
for i1=1:length(yl)-Ntp 
    rho(i1)=sum(yl(i1:i1+Ntp-1).*sptilde)/(E_sp*sqrt(sum(abs(yl(i1:i1+Ntp-1)).^2)));
end

%% Recherche du d�but d'une trame
% On recherche les valeurs de rho sup�rieur � 0.75
indice=find(rho>0.75);
if length(indice) == 0
    return;
elseif length(indice) == 1
    indice_final = indice(1);
elseif length(indice) >1
    % Si deux valeurs (ou plus) cons�cutives de rho sont sup�rieur � 0.75, alors on garde le premier indice 
    for i = 2:length(indice)
        if indice(i)==indice(i-1)+1
            indice_unique(i)=0;
        else
            indice_unique(i)=indice(i);
        end
    end
    ind=find(indice_unique>0);

    % Matrice contenant les indices de d�but de trame d�tect�e
    indice_final=indice_unique(:,ind); 
end
%% D�codage des trames
for i=1:length(indice_final)
    message=yl(indice_final(i)+Ntp:indice_final(i)+120*Fse);
    rl=conv(message,p_conj);
    rltilde = downsample(rl(Fse:end),Fse);
    vec=rltilde(1:end-1)<0;
    [ registre,error ] = bit2registre( vec,lon_ref,lat_ref );
    if error ~=1
        k = 0;
        for j=1:length(Reg_in)
            if registre.adresse == Reg_in(j).adresse 
                if registre.type >= 1 && registre.type <= 4
                    Reg_in(j).nom = registre.nom;
                elseif registre.type >= 9 && registre.type <= 22
                     Reg_in(j).cprFlag = registre.cprFlag;
                     Reg_in(j).altitude =  registre.altitude;
                     Reg_in(j).latitude =  registre.latitude;
                     Reg_in(j).longitude =  registre.longitude;
                     registre.trajectoire = [registre.longitude;registre.latitude];
                     Reg_in(j).trajectoire = [Reg_in(j).trajectoire,registre.trajectoire];
           
                end
                    k = 1;
            end
        end
        if k == 0
            Reg_in = [Reg_in,registre];
        end
    end
end
Reg_out = Reg_in;
end


